from flask import Flask, render_template, request, redirect, url_for, session, send_from_directory
from werkzeug.utils import secure_filename
import os
from flask_oauthlib.client import OAuth

app = Flask(__name__)
app.secret_key = '7dde15b11dfc1c64a0c81d0d932dadeaaa2268e0f70d8f5833f6426b6d21a96c'  # Change this to a secure secret key
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'jpg', 'jpeg', 'png', 'gif'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Set up OAuth for Google login
oauth = OAuth(app)
google = oauth.remote_app(
    'google',
    consumer_key='417104409802-klr1n9p93p2ikc7sngdbbv5ir8qp6iv1.apps.googleusercontent.com',
    consumer_secret='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',
    request_token_params={
        'scope': 'email',
    },
    base_url='https://www.googleapis.com/oauth2/v1/',
    request_token_url=None,
    access_token_method='POST',
    access_token_url='https://accounts.google.com/o/oauth2/token',
    authorize_url='https://accounts.google.com/o/oauth2/auth',
)

authenticated_user = None

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


@app.route('/')
def loggedin():
    global authenticated_user

    # Check if the user is authenticated (i.e., if 'google_token' is in the session)
    if 'google_token' in session:
        user_info = google.get('userinfo')
        authenticated_user = user_info

        # If the user is authenticated, render the 'loggedin.html' template
        if authenticated_user:
            return render_template('loggedin.html', user=authenticated_user)

    # If the user is not authenticated or there's no 'google_token' in the session,
    # redirect them to the login page
    return redirect(url_for('login'))



@app.route('/upload', methods=['GET', 'POST'])
def upload_file():
    global authenticated_user

    if 'google_token' in session:
        user_info = google.get('userinfo')
        authenticated_user = user_info

        if authenticated_user:
            if request.method == 'POST':
                if 'file' not in request.files:
                    return redirect(request.url)

                file = request.files['file']
                if file.filename == '':
                    return redirect(request.url)

                if file and allowed_file(file.filename):
                    filename = secure_filename(file.filename)
                    file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                    return redirect(url_for('result', filename=filename))

            return render_template('upload.html', user=authenticated_user)

@app.route('/index/<filename>')
def result(filename):
    return render_template('index.html', filename=filename, user=authenticated_user)

@app.route('/image/<filename>')
def view_image(filename):
    return render_template('view_image.html', filename=filename, user=authenticated_user)

@app.route('/login')
def login():
    return google.authorize(callback=url_for('authorized', _external=True))

@app.route('/logout')
def logout():
    session.pop('google_token', None)
    return redirect(url_for('login'))

@app.route('/login/authorized')
def authorized():
    resp = google.authorized_response()
    if resp is None or resp.get('access_token') is None:
        return 'Access denied: reason={} error={}'.format(
            request.args['error_reason'],
            request.args['error_description']
        )
    
    session['google_token'] = (resp['access_token'], '')
    user_info = google.get('userinfo')
    
    # Store or retrieve the user in your database based on user_info['id']
    # Here, you might want to associate the authenticated user with an account in your system
    
    return redirect(url_for('upload_file'))

@google.tokengetter
def get_google_oauth_token():
    return session.get('google_token')

if __name__ == '__main__':
    app.run(debug=True)
