from flask import render_template, request, redirect, url_for, jsonify
from flask_jwt_extended import jwt_required, create_access_token, get_jwt_identity
from werkzeug.utils import secure_filename
from flask_limiter.util import get_remote_address
from flask_limiter import Limiter
import os

UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'jpg', 'jpeg', 'png', 'gif'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Create a Flask-Limiter instance
limiter = Limiter(
    key_func=get_remote_address,
    default_limits=["5 per minute"],
)

# Import the app instance created in main.py
from main import app

@app.route('/', methods=['GET', 'POST'])
@jwt_required()
def upload_file():
    if request.method == 'POST':
        if 'file' not in request.files:
            return redirect(request.url)
        
        file = request.files['file']
        if file.filename == '':
            return redirect(request.url)
        
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file.save(os.path.join(UPLOAD_FOLDER, filename))
            return redirect(url_for('result', filename=filename))
    
    return render_template('upload.html')

@app.route('/result/<filename>')
def result(filename):
    return render_template('result.html', filename=filename)

@app.route('/login', methods=['POST'])
def login():
    username = request.json.get('username')
    password = request.json.get('password')

    # Replace with your own authentication logic
    if username == 'your_username' and password == 'your_password':
        access_token = create_access_token(identity=username)
        return {'access_token': access_token}
    else:
        return {'message': 'Invalid credentials'}, 401

@app.route('/api/protected', methods=['GET'])
@jwt_required()
def protected_route():
    current_user = get_jwt_identity()
    return {'message': f'Hello, {current_user}! This is a protected route.'}

@app.route('/api/limited', methods=['GET'])
@limiter.limit("5 per minute")
@jwt_required()
def limited_api_route():
    return {'message': 'This is a rate-limited API route.'}

if __name__ == '__main__':
    app.run(debug=True)
